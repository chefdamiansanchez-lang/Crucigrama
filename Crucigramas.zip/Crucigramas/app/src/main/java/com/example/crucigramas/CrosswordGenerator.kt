package com.example.crucigramas

enum class Direction { ACROSS, DOWN }

data class PlacedWord(
    val word: String,
    val clue: String,
    val row: Int,
    val col: Int,
    val direction: Direction,
    var number: Int = 0
)

class CrosswordResult(
    val size: Int,
    val grid: Array<CharArray>,      // ' ' = celda bloqueada/vacía, letra = celda usable
    val placedWords: List<PlacedWord>
)

/**
 * Generador de crucigramas por backtracking simple:
 * ordena las palabras de mayor a menor longitud, coloca la primera en el centro,
 * y para cada palabra siguiente busca la intersección con más letras en común
 * contra lo ya colocado en el tablero.
 */
object CrosswordGenerator {

    fun generate(size: Int = 15, wordCount: Int = 12): CrosswordResult {
        val candidates = WordBank.random(wordCount * 2) // margen extra por si alguna no entra
            .distinctBy { it.word }
            .sortedByDescending { it.word.length }
            .filter { it.word.length <= size }

        val grid = Array(size) { CharArray(size) { ' ' } }
        val placed = mutableListOf<PlacedWord>()

        // Colocar la primera palabra (la más larga) horizontal, centrada.
        val first = candidates.firstOrNull() ?: return CrosswordResult(size, grid, placed)
        val startRow = size / 2
        val startCol = (size - first.word.length) / 2
        placeWord(grid, first.word, startRow, startCol, Direction.ACROSS)
        placed.add(PlacedWord(first.word, first.clue, startRow, startCol, Direction.ACROSS))

        for (candidate in candidates.drop(1)) {
            if (placed.size >= wordCount) break
            val best = findBestPlacement(grid, size, candidate.word) ?: continue
            placeWord(grid, candidate.word, best.row, best.col, best.direction)
            placed.add(PlacedWord(candidate.word, candidate.clue, best.row, best.col, best.direction))
        }

        assignNumbers(placed)
        return CrosswordResult(size, grid, placed)
    }

    private data class Placement(val row: Int, val col: Int, val direction: Direction, val score: Int)

    private fun findBestPlacement(grid: Array<CharArray>, size: Int, word: String): Placement? {
        var best: Placement? = null

        for (r in 0 until size) {
            for (c in 0 until size) {
                val cell = grid[r][c]
                if (cell == ' ') continue

                // Buscar cada letra del cell que coincide con alguna letra de la palabra
                for ((i, ch) in word.withIndex()) {
                    if (ch != cell) continue

                    // Intento colocar cruzando en DOWN (la letra coincidente cae en fila r, col c,
                    // y la palabra nueva corre verticalmente)
                    val downRow = r - i
                    if (isValidPlacement(grid, size, word, downRow, c, Direction.DOWN)) {
                        val score = intersectionScore(grid, size, word, downRow, c, Direction.DOWN)
                        if (best == null || score > best.score) {
                            best = Placement(downRow, c, Direction.DOWN, score)
                        }
                    }

                    // Intento colocar cruzando en ACROSS
                    val acrossCol = c - i
                    if (isValidPlacement(grid, size, word, r, acrossCol, Direction.ACROSS)) {
                        val score = intersectionScore(grid, size, word, r, acrossCol, Direction.ACROSS)
                        if (best == null || score > best.score) {
                            best = Placement(r, acrossCol, Direction.ACROSS, score)
                        }
                    }
                }
            }
        }
        return best
    }

    private fun isValidPlacement(
        grid: Array<CharArray>, size: Int, word: String,
        row: Int, col: Int, dir: Direction
    ): Boolean {
        if (row < 0 || col < 0) return false
        val endRow = if (dir == Direction.DOWN) row + word.length - 1 else row
        val endCol = if (dir == Direction.ACROSS) col + word.length - 1 else col
        if (endRow >= size || endCol >= size) return false

        var hasIntersection = false

        for (i in word.indices) {
            val r = if (dir == Direction.DOWN) row + i else row
            val c = if (dir == Direction.ACROSS) col + i else col
            val existing = grid[r][c]

            if (existing != ' ') {
                if (existing != word[i]) return false
                hasIntersection = true
            } else {
                // Si la celda está vacía, las celdas perpendiculares adyacentes deben
                // estar vacías también, para no pegar palabras paralelas sin querer.
                if (dir == Direction.ACROSS) {
                    if (r - 1 >= 0 && grid[r - 1][c] != ' ') return false
                    if (r + 1 < size && grid[r + 1][c] != ' ') return false
                } else {
                    if (c - 1 >= 0 && grid[r][c - 1] != ' ') return false
                    if (c + 1 < size && grid[r][c + 1] != ' ') return false
                }
            }
        }

        // Celda anterior y posterior al inicio/fin deben estar vacías (no pegar con otra palabra
        // en la misma dirección).
        if (dir == Direction.ACROSS) {
            if (col - 1 >= 0 && grid[row][col - 1] != ' ') return false
            if (endCol + 1 < size && grid[row][endCol + 1] != ' ') return false
        } else {
            if (row - 1 >= 0 && grid[row - 1][col] != ' ') return false
            if (endRow + 1 < size && grid[endRow + 1][col] != ' ') return false
        }

        return hasIntersection
    }

    private fun intersectionScore(
        grid: Array<CharArray>, size: Int, word: String,
        row: Int, col: Int, dir: Direction
    ): Int {
        var score = 0
        for (i in word.indices) {
            val r = if (dir == Direction.DOWN) row + i else row
            val c = if (dir == Direction.ACROSS) col + i else col
            if (grid[r][c] != ' ') score++
        }
        return score
    }

    private fun placeWord(grid: Array<CharArray>, word: String, row: Int, col: Int, dir: Direction) {
        for (i in word.indices) {
            val r = if (dir == Direction.DOWN) row + i else row
            val c = if (dir == Direction.ACROSS) col + i else col
            grid[r][c] = word[i]
        }
    }

    /** Numera las palabras al estilo crucigrama clásico: un mismo número por celda de inicio. */
    private fun assignNumbers(placed: List<PlacedWord>) {
        val starts = placed.map { it.row to it.col }.distinct()
            .sortedWith(compareBy({ it.first }, { it.second }))
        val numberByCell = mutableMapOf<Pair<Int, Int>, Int>()
        var n = 1
        for (cell in starts) {
            numberByCell[cell] = n
            n++
        }
        placed.forEach { it.number = numberByCell[it.row to it.col] ?: 0 }
    }
}
