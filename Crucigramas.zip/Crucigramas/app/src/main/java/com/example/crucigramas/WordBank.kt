package com.example.crucigramas

data class WordClue(val word: String, val clue: String)

object WordBank {
    // Banco de palabras en español con sus pistas.
    // Se puede ampliar libremente agregando más entradas acá.
    val all: List<WordClue> = listOf(
        WordClue("SOL", "Astro que ilumina de día"),
        WordClue("LUNA", "Satélite natural de la Tierra"),
        WordClue("CASA", "Lugar donde se vive"),
        WordClue("PERRO", "Mejor amigo del hombre"),
        WordClue("GATO", "Felino doméstico"),
        WordClue("LIBRO", "Se lee página por página"),
        WordClue("ARBOL", "Tiene tronco, ramas y hojas"),
        WordClue("AGUA", "Líquido vital, H2O"),
        WordClue("FUEGO", "Arde y da calor"),
        WordClue("TIERRA", "Planeta donde vivimos"),
        WordClue("MAR", "Gran masa de agua salada"),
        WordClue("RIO", "Curso de agua que desemboca en el mar"),
        WordClue("MONTE", "Elevación natural del terreno"),
        WordClue("FLOR", "Parte colorida de una planta"),
        WordClue("PAN", "Se hace con harina y se hornea"),
        WordClue("LECHE", "Bebida blanca que dan las vacas"),
        WordClue("MESA", "Mueble con patas para comer o trabajar"),
        WordClue("SILLA", "Mueble para sentarse"),
        WordClue("PUERTA", "Se abre para entrar a un lugar"),
        WordClue("VENTANA", "Deja pasar la luz a una habitación"),
        WordClue("COCHE", "Vehículo con cuatro ruedas"),
        WordClue("TREN", "Transporte que va sobre rieles"),
        WordClue("AVION", "Vuela y transporta pasajeros"),
        WordClue("BARCO", "Navega sobre el agua"),
        WordClue("ESCUELA", "Lugar donde se estudia"),
        WordClue("MAESTRO", "Enseña en la escuela"),
        WordClue("MUSICA", "Arte de combinar sonidos"),
        WordClue("PINTURA", "Arte que usa colores sobre un lienzo"),
        WordClue("DEPORTE", "Actividad física competitiva"),
        WordClue("FUTBOL", "Deporte con una pelota y dos arcos"),
        WordClue("TENIS", "Deporte que se juega con raqueta"),
        WordClue("PLAYA", "Costa de arena junto al mar"),
        WordClue("NIEVE", "Cae blanca en invierno"),
        WordClue("LLUVIA", "Cae del cielo cuando está nublado"),
        WordClue("VIENTO", "Aire en movimiento"),
        WordClue("ESTRELLA", "Brilla en el cielo nocturno"),
        WordClue("PLANETA", "La Tierra es uno"),
        WordClue("COLOR", "Rojo, verde y azul son ejemplos"),
        WordClue("NUMERO", "Se usa para contar"),
        WordClue("TIEMPO", "Se mide en horas y minutos"),
        WordClue("AMIGO", "Persona con quien compartís confianza"),
        WordClue("FAMILIA", "Padres, hijos y hermanos"),
        WordClue("CIUDAD", "Conjunto grande de calles y edificios"),
        WordClue("PAIS", "Territorio con su propio gobierno"),
        WordClue("IDIOMA", "Lengua que se habla en un lugar"),
        WordClue("COMIDA", "Se prepara y se come"),
        WordClue("FRUTA", "La manzana y la banana lo son"),
        WordClue("VERDURA", "La zanahoria y la lechuga lo son"),
        WordClue("QUESO", "Se hace con leche cuajada"),
        WordClue("CAFE", "Bebida oscura que despierta"),
        WordClue("TE", "Bebida caliente con hojas infusionadas")
    )

    fun random(count: Int): List<WordClue> {
        return all.shuffled().take(count)
    }
}
