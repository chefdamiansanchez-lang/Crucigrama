package com.example.crucigramas

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputFilter
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private lateinit var acrossContainer: LinearLayout
    private lateinit var downContainer: LinearLayout

    private var result: CrosswordResult? = null
    private val cellInputs = mutableMapOf<Pair<Int, Int>, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gridLayout = findViewById(R.id.gridLayout)
        acrossContainer = findViewById(R.id.acrossContainer)
        downContainer = findViewById(R.id.downContainer)

        findViewById<android.widget.Button>(R.id.btnCheck).setOnClickListener { checkAnswers() }
        findViewById<android.widget.Button>(R.id.btnNew).setOnClickListener { newCrossword() }

        newCrossword()
    }

    private fun newCrossword() {
        val r = CrosswordGenerator.generate(size = 13, wordCount = 10)
        result = r
        buildGrid(r)
        buildClueLists(r)
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    private fun buildGrid(result: CrosswordResult) {
        gridLayout.removeAllViews()
        cellInputs.clear()

        // Recortar el tablero a la zona realmente usada para no mostrar bordes vacíos enormes.
        var minRow = result.size; var maxRow = 0
        var minCol = result.size; var maxCol = 0
        for (r in 0 until result.size) {
            for (c in 0 until result.size) {
                if (result.grid[r][c] != ' ') {
                    if (r < minRow) minRow = r
                    if (r > maxRow) maxRow = r
                    if (c < minCol) minCol = c
                    if (c > maxCol) maxCol = c
                }
            }
        }
        if (minRow > maxRow) return // no se pudo generar nada

        val rows = maxRow - minRow + 1
        val cols = maxCol - minCol + 1
        gridLayout.columnCount = cols
        gridLayout.rowCount = rows

        // Mapa celda -> número (para pintar el numerito en la esquina)
        val numberAt = mutableMapOf<Pair<Int, Int>, Int>()
        result.placedWords.forEach { numberAt[it.row to it.col] = it.number }

        val cellSize = dp(30)

        for (r in minRow..maxRow) {
            for (c in minCol..maxCol) {
                val letter = result.grid[r][c]
                val frame = FrameLayout(this).apply {
                    layoutParams = GridLayout.LayoutParams(
                        GridLayout.spec(r - minRow),
                        GridLayout.spec(c - minCol)
                    ).apply {
                        width = cellSize
                        height = cellSize
                        setMargins(1, 1, 1, 1)
                    }
                }

                if (letter == ' ') {
                    frame.setBackgroundColor(Color.parseColor("#212121"))
                } else {
                    frame.setBackgroundColor(Color.WHITE)
                    val edit = EditText(this).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        gravity = Gravity.CENTER
                        filters = arrayOf(InputFilter.LengthFilter(1))
                        setBackgroundColor(Color.WHITE)
                        setPadding(0, 0, 0, 0)
                        textSize = 16f
                        setTextColor(Color.BLACK)
                    }
                    cellInputs[r to c] = edit
                    frame.addView(edit)

                    val num = numberAt[r to c]
                    if (num != null) {
                        val label = TextView(this).apply {
                            text = num.toString()
                            textSize = 8f
                            setTextColor(Color.DKGRAY)
                            setPadding(2, 0, 0, 0)
                        }
                        frame.addView(label)
                    }
                }
                gridLayout.addView(frame)
            }
        }
    }

    private fun buildClueLists(result: CrosswordResult) {
        acrossContainer.removeAllViews()
        downContainer.removeAllViews()

        val acrossTitle = TextView(this).apply {
            text = "Horizontales"
            setTypeface(null, Typeface.BOLD)
            textSize = 15f
        }
        acrossContainer.addView(acrossTitle)

        val downTitle = TextView(this).apply {
            text = "Verticales"
            setTypeface(null, Typeface.BOLD)
            textSize = 15f
        }
        downContainer.addView(downTitle)

        result.placedWords.sortedBy { it.number }.forEach { pw ->
            val line = TextView(this).apply {
                text = "${pw.number}. ${pw.clue}"
                textSize = 13f
                setPadding(0, dp(4), 0, dp(4))
            }
            if (pw.direction == Direction.ACROSS) acrossContainer.addView(line)
            else downContainer.addView(line)
        }
    }

    private fun checkAnswers() {
        val r = result ?: return
        var allFilled = true
        var allCorrect = true

        for ((pos, edit) in cellInputs) {
            val (row, col) = pos
            val expected = r.grid[row][col]
            val typed = edit.text.toString().uppercase().firstOrNull()
            if (typed == null) {
                allFilled = false
                edit.setBackgroundColor(Color.WHITE)
            } else if (typed == expected) {
                edit.setBackgroundColor(Color.parseColor("#C8E6C9")) // verde clarito
            } else {
                allCorrect = false
                edit.setBackgroundColor(Color.parseColor("#FFCDD2")) // rojo clarito
            }
        }

        val message = when {
            !allFilled -> "Todavía faltan casilleros por completar"
            allCorrect -> "¡Crucigrama resuelto correctamente!"
            else -> "Hay errores marcados en rojo"
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
